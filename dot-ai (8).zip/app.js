
/**
 * DOT AI - Vanilla JS Logic
 * "Backendless" architecture using localStorage
 */

(function() {
    'use strict';

    const DB_KEYS = {
        USER: 'dotai_current_user',
        USERS: 'dotai_users_db',
        GALLERY: 'dotai_gallery_db',
        REQUESTS: 'dotai_requests_db',
        SUPPORT: 'dotai_support_db'
    };

    const MOCK_DELAY = 600;

    // --- State Management ---
    const Store = {
        get: function(key, def) {
            try {
                const val = localStorage.getItem(key);
                return val ? JSON.parse(val) : def;
            } catch (e) {
                return def;
            }
        },
        set: function(key, val) {
            localStorage.setItem(key, JSON.stringify(val));
        },
        
        getUser: function() {
            const val = localStorage.getItem(DB_KEYS.USER);
            return val ? JSON.parse(val) : null;
        },
        getUsers: function() {
            const val = localStorage.getItem(DB_KEYS.USERS);
            return val ? JSON.parse(val) : [];
        },
        
        init: function() {
            const usersStr = localStorage.getItem(DB_KEYS.USERS);
            const parsedUsers = usersStr ? JSON.parse(usersStr) : [];
            const adminExists = parsedUsers.find(function(u) { return u.email === 'admin@dot.ai'; });
            if (!adminExists) {
                parsedUsers.push({
                    id: 'admin', name: 'Admin User', email: 'admin@dot.ai', 
                    password: 'admin', role: 'admin', credits: 9999, 
                    joined: new Date().toISOString()
                });
                localStorage.setItem(DB_KEYS.USERS, JSON.stringify(parsedUsers));
            }
        }
    };

    // --- Utils ---
    const Utils = {
        delay: function(ms) { return new Promise(function(res) { setTimeout(res, ms); }); },
        
        toast: function(msg, type) {
            const tType = type || 'success';
            let container = document.getElementById('toast-container');
            if (!container) {
                const div = document.createElement('div');
                div.id = 'toast-container';
                div.className = 'toast-container';
                document.body.appendChild(div);
                container = div;
            }
            const el = document.createElement('div');
            el.className = 'toast ' + tType;
            el.textContent = msg;
            container.appendChild(el);
            setTimeout(function() { if(el.parentNode) el.parentNode.removeChild(el); }, 3000);
        },

        fileToBase64: function(file) {
            return new Promise(function(resolve, reject) {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = function() { resolve(reader.result); };
                reader.onerror = function(error) { reject(error); };
            });
        },

        downloadImage: async function(url, filename) {
            try {
                let blobUrl = url;
                if (url.startsWith('data:')) {
                    const response = await fetch(url);
                    const blob = await response.blob();
                    blobUrl = window.URL.createObjectURL(blob);
                }
                
                const link = document.createElement('a');
                link.href = blobUrl;
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                if (url.startsWith('data:')) {
                    window.URL.revokeObjectURL(blobUrl);
                }
                Utils.toast('Download started');
            } catch (e) {
                console.error(e);
                const link = document.createElement('a');
                link.href = url;
                link.target = '_blank';
                link.download = filename;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        },

        shareImage: async function(title, url) {
            if (navigator.share) {
                try {
                    await navigator.share({ title: 'DOT AI', text: title, url: url });
                } catch (err) { console.log('Share cancelled'); }
            } else {
                navigator.clipboard.writeText(url);
                Utils.toast('Link copied to clipboard');
            }
        }
    };

    // --- Auth Service ---
    const Auth = {
        login: async function(email, password) {
            await Utils.delay(MOCK_DELAY);
            const users = Store.getUsers();
            const user = users.find(function(u) { return u.email === email && u.password === password; });
            if (user) {
                if (user.status === 'blocked') throw new Error('Account is blocked');
                Store.set(DB_KEYS.USER, user);
                return user;
            }
            throw new Error('Invalid credentials');
        },
        signup: async function(name, email, password) {
            await Utils.delay(MOCK_DELAY);
            const users = Store.getUsers();
            if (users.find(function(u) { return u.email === email; })) throw new Error('Email already exists');
            
            const newUser = {
                id: Date.now().toString(),
                name: name, 
                email: email, 
                password: password,
                role: 'user',
                status: 'active',
                credits: 25,
                joined: new Date().toISOString()
            };
            
            users.push(newUser);
            Store.set(DB_KEYS.USERS, users);
            Store.set(DB_KEYS.USER, newUser);
            return newUser;
        },
        updateUser: function(updates) {
            const user = Store.getUser();
            if (!user) return;
            const updated = Object.assign({}, user, updates);
            Store.set(DB_KEYS.USER, updated);
            
            // Update in full DB too
            const users = Store.getUsers();
            const idx = users.findIndex(function(u) { return u.id === user.id; });
            if (idx !== -1) {
                users[idx] = updated;
                Store.set(DB_KEYS.USERS, users);
            }
            UI.renderHeader(); // Refresh header
        },
        requireAuth: function() {
            if (!Store.getUser()) {
                window.location.href = 'login.html';
            }
        },
        logout: function() {
            localStorage.removeItem(DB_KEYS.USER);
            window.location.href = 'index.html';
        }
    };

    // --- UI Components ---
    const UI = {
        renderHeader: function() {
            const header = document.querySelector('header');
            if (!header) return;
            const user = Store.getUser();
            
            let navHtml = '';
            if (user) {
                navHtml = `
                    <div class="nav-links">
                        <a href="generator.html">Create</a>
                        <a href="gallery.html">Gallery</a>
                        <a href="favorites.html">Favorites</a>
                        <a href="buy-credits.html">Credits: ${user.credits}</a>
                        <a href="profile.html">${user.name}</a>
                        ${user.role === 'admin' ? '<a href="admin.html" class="text-accent">Admin</a>' : ''}
                        <a href="#" onclick="Auth.logout()">Logout</a>
                    </div>
                    <button class="mobile-menu-btn" onclick="document.querySelector('.nav-links').classList.toggle('hidden')">☰</button>
                `;
            } else {
                navHtml = `
                    <div class="nav-links">
                        <a href="index.html">Home</a>
                        <a href="gallery.html">Gallery</a>
                        <a href="login.html" class="btn btn-sm btn-secondary">Login</a>
                        <a href="signup.html" class="btn btn-sm btn-primary">Sign Up</a>
                    </div>
                     <button class="mobile-menu-btn" onclick="document.querySelector('.nav-links').classList.toggle('hidden')">☰</button>
                `;
            }

            header.innerHTML = `
                <div class="container flex justify-between items-center">
                    <a href="index.html" class="logo">DOT AI</a>
                    ${navHtml}
                </div>
            `;
        },

        renderGallery: function(images, containerId, isProfile) {
            const container = document.getElementById(containerId);
            if(!container) return;
            
            if(images.length === 0) {
                container.innerHTML = '<p class="text-secondary" style="grid-column: 1/-1; text-align:center;">No images found.</p>';
                return;
            }

            container.innerHTML = images.map(function(img) {
                return `
                <div class="image-card">
                    <img src="${img.url}" loading="lazy" alt="${img.prompt}">
                    <div class="image-overlay">
                        <p class="text-sm font-bold" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${img.prompt}</p>
                        <p class="text-xs text-secondary">by ${img.authorName}</p>
                        <div class="flex justify-between mt-2">
                            <button onclick="Actions.like('${img.id}')" class="btn btn-sm btn-secondary">❤️ ${img.likes}</button>
                            <button onclick="Actions.download('${img.url}', 'img-${img.id}.jpg')" class="btn btn-sm btn-secondary">⬇️</button>
                        </div>
                    </div>
                </div>
                `;
            }).join('');
        }
    };

    // --- Actions ---
    const Actions = {
        download: function(url, filename) {
            Utils.downloadImage(url, filename);
        },
        like: function(id) {
            const gallery = Store.get(DB_KEYS.GALLERY, []);
            const img = gallery.find(function(i) { return i.id === id; });
            if(img) {
                img.likes++;
                Store.set(DB_KEYS.GALLERY, gallery);
                Utils.toast('Liked!');
                // Simple reload to reflect changes in vanilla js
                setTimeout(function() { window.location.reload(); }, 300);
            }
        }
    };

    // --- Init ---
    Store.init();
    UI.renderHeader();

    // Expose to Window for Inline Scripts
    window.Store = Store;
    window.Utils = Utils;
    window.Auth = Auth;
    window.UI = UI;
    window.Actions = Actions;

})();
