
import React, { useEffect } from 'react';

interface ToastProps {
  message: string;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 4000);

    return () => {
      clearTimeout(timer);
    };
  }, [onClose]);

  const baseClasses = "fixed bottom-5 right-5 text-white py-3 px-5 rounded-lg shadow-xl animate-slide-in-up z-50 text-sm font-medium";
  
  let typeClasses = '';
  switch (type) {
      case 'success':
          typeClasses = 'bg-black dark:bg-white dark:text-black';
          break;
      case 'error':
          typeClasses = 'bg-red-600';
          break;
      case 'info':
          typeClasses = 'bg-blue-600';
          break;
      default:
          typeClasses = 'bg-black dark:bg-white dark:text-black';
  }

  return (
    <div className={`${baseClasses} ${typeClasses}`}>
      {message}
    </div>
  );
};

export default Toast;
